from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    categoria = models.CharField(max_length=50)
    unidad = models.CharField(max_length=20)
    precio = models.PositiveIntegerField()
    precio_compra = models.PositiveIntegerField(null=True, blank=True)
    stock = models.PositiveIntegerField()
    estado = models.CharField(max_length=50)
    stock_minimo = models.PositiveIntegerField(default=30)
    stock_maximo = models.PositiveIntegerField(default=100)
    fecha_modificacion = models.DateTimeField(auto_now=True)
    local = models.CharField(max_length=50, default='default_local')


    def __str__(self):
        return self.nombre

class Movimiento(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField()
    fecha = models.DateTimeField(auto_now_add=True)   


    def __str__(self):
        return f"{self.usuario.username} ingresó {self.cantidad} de {self.producto.nombre}"

class Perfil(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    local = models.CharField(max_length=50, db_column='local_id', null=True, blank=True)
    nombre_local = models.CharField(max_length=100, null=True, blank=True)

    class Meta:
        managed = False  # evita que Django cree o modifique esta tabla
        db_table = 'usuarios_perfil'  # usa la tabla real existente

    def __str__(self):
        return f"{self.user.username} - Local {self.local} ({self.nombre_local})"








