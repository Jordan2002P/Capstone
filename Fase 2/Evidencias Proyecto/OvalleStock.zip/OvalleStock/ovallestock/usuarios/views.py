from django.db import models
from django.db.models import Case, When, IntegerField
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.contrib.auth import logout
from .forms import ProductoForm
from .models import Producto
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from .models import Perfil
from .forms import RegistroUsuarioForm
from .models import Movimiento
from django.utils.timezone import now
from django.contrib.auth import get_user_model






def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('principal')
        else:
            return render(request, 'usuarios/login.html', {'error': 'Credenciales inválidas'})
    return render(request, 'usuarios/login.html')

def productos(request):
    orden = request.GET.get('orden', 'nombre')

    if request.user.is_superuser:
        productos = Producto.objects.all()
    else:
        perfil = Perfil.objects.get(user=request.user)
        productos = Producto.objects.filter(local=perfil.local)

    productos = productos.annotate(
        prioridad_estado=Case(
            When(stock__gt=15, then=0),
            When(stock__gt=5, then=1),
            When(stock__lte=5, then=2),
            output_field=IntegerField()
        )
    )

    if orden == 'estado':
        productos = productos.order_by('prioridad_estado')
    elif orden == '-estado':
        productos = productos.order_by('-prioridad_estado')
    else:
        productos = productos.order_by(orden)

    for p in productos:
        if p.stock <= 5:
            p.clase = "bajo"
            p.estado = "Stock Bajo"
        elif p.stock <= 15:
            p.clase = "limitado"
            p.estado = "Stock Limitado"
        else:
            p.clase = "disponible"
            p.estado = "Disponible"

    return render(request, 'usuarios/productos.html', {'productos': productos})


def agregar_producto(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST or None)
        if form.is_valid():
            nombre = form.cleaned_data['nombre'].strip().capitalize()
            categoria = form.cleaned_data['categoria'].strip().capitalize()
            unidad = form.cleaned_data['unidad']
            precio = form.cleaned_data['precio']
            precio_compra = form.cleaned_data['precio_compra'] 
            stock = form.cleaned_data['stock']

            perfil = Perfil.objects.get(user=request.user)


            try:
                producto_existente = Producto.objects.get(
                    nombre__iexact=nombre,
                    categoria__iexact=categoria,
                    local=perfil.local
                )

                producto_existente.unidad = unidad
                producto_existente.precio = precio
                producto_existente.stock += stock

                if producto_existente.stock <= 5:
                    producto_existente.estado = "Stock Bajo"
                elif producto_existente.stock <= 15:
                    producto_existente.estado = "Stock Limitado"
                else:
                    producto_existente.estado = "Disponible"

                producto_existente.save()

                Movimiento.objects.create(
                    usuario=request.user,
                    producto=producto_existente,
                    cantidad=stock
                )

            except Producto.DoesNotExist:
                nuevo_producto = form.save(commit=False)
                nuevo_producto.nombre = nombre
                nuevo_producto.categoria = categoria
                nuevo_producto.local = perfil.local
                nuevo_producto.precio_compra = precio_compra

                if stock <= 5:
                    nuevo_producto.estado = "Stock Bajo"
                elif stock <= 15:
                    nuevo_producto.estado = "Stock Limitado"
                else:
                    nuevo_producto.estado = "Disponible"

                nuevo_producto.save()

                Movimiento.objects.create(
                    usuario=request.user,
                    producto=nuevo_producto,
                    cantidad=stock
                )

            return redirect('productos')
    else:
        form = ProductoForm()

    return render(request, 'usuarios/agregar_producto.html', {'form': form})





@login_required(login_url='/')  
def principal_view(request):
    return render(request, 'usuarios/principal.html')

@login_required(login_url='/')
def dashboard_view(request):
    return render(request, 'usuarios/dashboard.html')

@login_required(login_url='/')
def productos_view(request):
    return render(request, 'usuarios/productos.html')

@login_required(login_url='/')
def movimientos_view(request):
    return render(request, 'usuarios/movimientos.html')

@login_required(login_url='/')
def reportes_view(request):
    return render(request, 'usuarios/reportes.html')

@login_required(login_url='/')
def perfil_view(request):
    return render(request, 'usuarios/perfil.html')

def logout_view(request):
    logout(request)
    return redirect('/')

@login_required
def perfil_usuario(request):
    user = request.user
    try:
        perfil = user.perfil  
    except Perfil.DoesNotExist:
        perfil = Perfil.objects.create(user=user)

    if request.method == 'POST':
        user.first_name = request.POST.get('first_name')
        user.last_name = request.POST.get('last_name')
        user.email = request.POST.get('email')

        user.save()
        perfil.save()

        messages.success(request, 'Perfil actualizado correctamente.')
        return redirect('perfil')  

    return render(request, 'usuarios/perfil.html', {'user': user, 'perfil': perfil})



@login_required
@user_passes_test(lambda u: u.is_staff)
def registro_usuario(request):
    if request.method == 'POST':
        form = RegistroUsuarioForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Usuario registrado correctamente.')
            return redirect('principal')
        else:
            messages.error(request, 'Corrige los errores en el formulario.')
    else:
        form = RegistroUsuarioForm()

    return render(request, 'usuarios/registro_usuario.html', {'form': form})











@login_required
def movimientos_view(request):
    if not request.user.is_superuser:
        return redirect('productos')

    movimientos = Movimiento.objects.select_related('usuario', 'producto').order_by('-id')
    agrupados = {}

    for m in movimientos:
        local_id = m.producto.local 

        if local_id not in agrupados:
            perfil_local = Perfil.objects.filter(local=local_id).first()
            nombre_local = perfil_local.nombre_local if perfil_local else f"Local {local_id}"

            agrupados[local_id] = {
                'nombre': nombre_local,
                'movimientos': []
            }

        agrupados[local_id]['movimientos'].append(m)

    agrupados_ordenados = dict(sorted(agrupados.items()))
    return render(request, 'usuarios/movimientos.html', {'agrupados': agrupados_ordenados})


@login_required(login_url='/')
def reportes_view(request):
    if request.user.is_superuser:
        productos = Producto.objects.all()
    else:
        perfil = Perfil.objects.get(user=request.user)
        productos = Producto.objects.filter(local=perfil.local)

    productos_bajo = productos.filter(stock__lte=models.F('stock_minimo'))
    productos_alto = productos.filter(stock__gte=models.F('stock_maximo'))

    contexto = {
        'productos_bajo': productos_bajo,
        'productos_alto': productos_alto,
    }
    return render(request, 'usuarios/reportes.html', contexto)



def editar_producto(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)

    if request.user.is_superuser:
        if producto.local != 'default_local':
            messages.error(request, "El administrador no puede editar productos asignados.")
            return redirect('productos')
    else:
        perfil = Perfil.objects.get(user=request.user)
        if producto.local != perfil.local:
            messages.error(request, "No tienes permiso para editar este producto.")
            return redirect('productos')

    if request.method == 'POST':
        form = ProductoForm(request.POST or None, instance=producto, modo_edicion=True)

        if form.is_valid():
            producto = form.save(commit=False)

            if not request.user.is_superuser:
                perfil = Perfil.objects.get(user=request.user)
                producto.local = perfil.local

            if producto.stock <= 5:
                producto.estado = "Stock Bajo"
            elif producto.stock <= 15:
                producto.estado = "Stock Limitado"
            else:
                producto.estado = "Disponible"

            producto.save()
            return redirect('productos')
    else:
        form = ProductoForm(instance=producto, modo_edicion=True)

    return render(request, 'usuarios/editar_producto.html', {'form': form, 'producto': producto})




def eliminar_producto(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)

    if request.user.is_superuser:
        messages.error(request, "El administrador no puede eliminar productos.")
        return redirect('productos')

    perfil = Perfil.objects.get(user=request.user)
    if producto.local != perfil.local:
        messages.error(request, "No tienes permiso para eliminar este producto.")
        return redirect('productos')

    producto.delete()
    return redirect('productos')



def restablecer_contraseña(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        nueva = request.POST.get('nueva_contraseña')
        confirmar = request.POST.get('confirmar_contraseña')

        if nueva != confirmar:
            messages.error(request, "Las contraseñas no coinciden.")
        else:
            try:
                usuario = User.objects.get(username=username)
                usuario.password = make_password(nueva)
                usuario.save()
                messages.success(request, "Contraseña actualizada correctamente.")
                return redirect('login')  
            except User.DoesNotExist:
                messages.error(request, "Usuario no encontrado.")

    return render(request, 'usuarios/restablecer_contraseña.html')



@login_required
def dashboard(request):
    hoy = now().date()

    if not request.user.is_superuser:
        return redirect('productos')

    locales_ids = Producto.objects.values_list('local', flat=True).distinct()

    dashboards_por_local = {}

    for local_id in locales_ids:
        productos_modificados = Producto.objects.filter(
            fecha_modificacion__date=hoy,
            local=local_id
        ).count()

        movimientos_hoy = Movimiento.objects.filter(
            fecha__date=hoy,
            producto__local=local_id
        ).count()

        productos_stock_bajo = Producto.objects.filter(
            stock__lt=15,
            local=local_id
        ).count()

        perfil_local = Perfil.objects.filter(local=local_id).first()
        nombre_local = perfil_local.nombre_local if perfil_local else f"Local {local_id}"

        ultima_actualizacion = Movimiento.objects.filter(producto__local=local_id).order_by('-fecha').first()
        ultima_fecha = ultima_actualizacion.fecha.strftime('%d-%m-%Y %H:%M') if ultima_actualizacion else "Sin movimientos"

        dashboards_por_local[local_id] = {
            'nombre': nombre_local,
            'productos_modificados': productos_modificados,
            'movimientos_hoy': movimientos_hoy,
            'productos_stock_bajo': productos_stock_bajo,
            'ultima_actualizacion': ultima_fecha,
        }

    dashboards_ordenados = dict(sorted(dashboards_por_local.items()))
    return render(request, 'usuarios/dashboard.html', {
        'dashboards_por_local': dashboards_ordenados,
        'hoy': hoy.strftime('%d-%m-%Y'),
    })






@login_required
def vista_admin_productos(request):
    if not request.user.is_superuser:
        return redirect('productos')

    productos = Producto.objects.all().order_by('local', 'nombre')
    inventarios = {}

    for p in productos:
        if p.stock <= 5:
            p.estado = "Stock Bajo"
            p.clase = "bajo"
        elif p.stock <= 15:
            p.estado = "Stock Limitado"
            p.clase = "limitado"
        else:
            p.estado = "Disponible"
            p.clase = "disponible"

        if p.precio_compra and p.precio_compra > 0:
            p.margen = round(((p.precio - p.precio_compra) / p.precio_compra) * 100, 1)
        else:
            p.margen = None

        local_id = p.local
        if local_id not in inventarios:

            perfil_local = Perfil.objects.filter(local=local_id).first()
            nombre_local = perfil_local.nombre_local if perfil_local else f"Local {local_id}"

            inventarios[local_id] = {
                'productos': [],
                'total_compra': 0,
                'total_venta': 0,
                'rentabilidad': None,
                'nombre': nombre_local
            }

        inventarios[local_id]['productos'].append(p)

        if p.precio_compra and p.stock:
            inventarios[local_id]['total_compra'] += p.precio_compra * p.stock
            inventarios[local_id]['total_venta'] += p.precio * p.stock

    for data in inventarios.values():
        if data['total_compra'] > 0:
            data['rentabilidad'] = round(((data['total_venta'] - data['total_compra']) / data['total_compra']) * 100, 1)

    return render(request, 'usuarios/productos_admin.html', {'inventarios': inventarios})


@login_required
def usuarios_por_local(request):
    if not request.user.is_superuser:
        return redirect('productos')

    usuarios = User.objects.filter(is_superuser=False).select_related('perfil')
    agrupados = {}

    for u in usuarios:
        perfil = getattr(u, 'perfil', None)
        if perfil:
            local_id = perfil.local
            nombre_local = perfil.nombre_local

            if local_id not in agrupados:
                agrupados[local_id] = {
                    'nombre_local': nombre_local,
                    'usuarios': []
                }

            agrupados[local_id]['usuarios'].append(u)

    agrupados_ordenados = dict(sorted(agrupados.items()))
    return render(request, 'usuarios/usuarios_por_local.html', {'agrupados': agrupados_ordenados})


@login_required
def eliminar_usuario(request, user_id):
    if not request.user.is_superuser:
        return redirect('productos')

    usuario = get_user_model().objects.filter(id=user_id, is_superuser=False).first()
    if usuario:
        usuario.delete()
    return redirect('usuarios_por_local')
