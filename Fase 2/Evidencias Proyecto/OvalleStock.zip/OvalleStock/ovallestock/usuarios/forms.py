from django import forms
from .models import Producto
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Perfil


class ProductoForm(forms.ModelForm):
    codigo = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Escanea o ingresa el código del producto',
            'id': 'codigo-input'
        })
    )

    def __init__(self, *args, **kwargs):
        modo_edicion = kwargs.pop('modo_edicion', False)
        super().__init__(*args, **kwargs)

        if modo_edicion:
            self.fields['codigo'].widget = forms.HiddenInput()

    class Meta:
        model = Producto
        fields = ['nombre', 'categoria', 'unidad', 'precio', 'precio_compra', 'stock', 'codigo']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'categoria': forms.TextInput(attrs={'class': 'form-control'}),
            'unidad': forms.TextInput(attrs={'class': 'form-control'}),
            'precio': forms.NumberInput(attrs={'class': 'form-control'}),
            'precio_compra': forms.NumberInput(attrs={'class': 'form-control'}),
            'stock': forms.NumberInput(attrs={'class': 'form-control'}),
        }



LOCALES = {
    "10": "El Rincón de las Frutas",
    "11": "El Rincón Urbano",
    "12": "El Guatón de la Fruta",
    "13": "El Rey de las Paltas"
}

class RegistroUsuarioForm(UserCreationForm):
    email = forms.EmailField(required=True, label="Correo electrónico")

    local = forms.ChoiceField(
        required=True,
        label="Número de local",
        choices=[('', 'Selecciona un local')] + [(k, f"Local {k}") for k in LOCALES.keys()],
        widget=forms.Select(attrs={'id': 'local-select', 'class': 'select-local'})
    )

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2', 'local']

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.set_password(self.cleaned_data['password1'])

        if commit:
            user.save()
            local_id = self.cleaned_data['local']
            nombre_local = LOCALES.get(local_id, "Sin nombre")
            Perfil.objects.create(user=user, local=local_id, nombre_local=nombre_local)

        return user



