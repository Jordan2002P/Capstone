from django.urls import path
from . import views

urlpatterns = [

    path('', views.login_view, name='login'),
    path('principal/', views.principal_view, name='principal'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('productos/', views.productos, name='productos'),
    path('productos/agregar/', views.agregar_producto, name='agregar_producto'),
    path('productos/editar/<int:producto_id>/', views.editar_producto, name='editar_producto'),
    path('productos/eliminar/<int:producto_id>/', views.eliminar_producto, name='eliminar_producto'),
    path('movimientos/', views.movimientos_view, name='movimientos'),
    path('reportes/', views.reportes_view, name='reportes'),
    path('perfil/', views.perfil_usuario, name='perfil'),
    path('logout/', views.logout_view, name='logout'),
    path('registrar/', views.registro_usuario, name='registro_usuario'),
    path('restablecer/', views.restablecer_contraseña, name='restablecer_contraseña'),
    path('productosadmin/', views.vista_admin_productos, name='productos_admin'),
    path('usuarios-por-local/', views.usuarios_por_local, name='usuarios_por_local'),
    path('eliminar-usuario/<int:user_id>/', views.eliminar_usuario, name='eliminar_usuario'),
]