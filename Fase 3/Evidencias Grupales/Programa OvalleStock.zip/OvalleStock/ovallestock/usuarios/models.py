from django.db import models
from django.contrib.auth.models import User


class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    categoria = models.CharField(max_length=50)
    unidad = models.CharField(max_length=20)
    precio = models.PositiveIntegerField()
    precio_compra = models.PositiveIntegerField(null=True, blank=True)
    stock = models.PositiveIntegerField()
    estado = models.CharField(max_length=50)
    stock_minimo = models.PositiveIntegerField(default=30)
    stock_maximo = models.PositiveIntegerField(default=100)
    fecha_modificacion = models.DateTimeField(auto_now=True)
    local = models.CharField(max_length=50, default='default_local')


    def __str__(self):
        return self.nombre

class Movimiento(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField()
    fecha = models.DateTimeField(auto_now_add=True)
    tipo = models.CharField(max_length=20, default="ingreso")

    def __str__(self):
        return f"{self.usuario.username} {self.tipo} {self.cantidad} de {self.producto.nombre}"



class Perfil(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    local = models.CharField(max_length=50, db_column='local_id', null=True, blank=True)
    nombre_local = models.CharField(max_length=100, null=True, blank=True)
    es_encargado = models.BooleanField(default=False)

    local_fk = models.ForeignKey(
        'Local',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        db_column='local_fk_id'
    )

    class Meta:
        managed = False  
        db_table = 'usuarios_perfil'

    def __str__(self):
        return f"{self.user.username} - Local {self.local} ({self.nombre_local})"




class Local(models.Model):
    numero = models.CharField(max_length=50, unique=True)
    nombre = models.CharField(max_length=100)

    class Meta:
        db_table = 'usuarios_local'
        managed = False  

    def __str__(self):
        return f"Local {self.numero} - {self.nombre}"






