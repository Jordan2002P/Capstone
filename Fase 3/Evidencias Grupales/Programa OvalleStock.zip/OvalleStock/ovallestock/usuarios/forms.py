from django import forms
from .models import Producto
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Perfil
from .models import Local



class ProductoForm(forms.ModelForm):
    codigo = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Escanea o ingresa el código del producto',
            'id': 'codigo-input'
        })
    )

    def __init__(self, *args, **kwargs):
        modo_edicion = kwargs.pop('modo_edicion', False)
        super().__init__(*args, **kwargs)

        if modo_edicion:
            self.fields['codigo'].widget = forms.HiddenInput()

    class Meta:
        model = Producto
        fields = ['nombre', 'categoria', 'unidad', 'precio', 'precio_compra', 'stock', 'codigo']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'categoria': forms.TextInput(attrs={'class': 'form-control'}),
            'unidad': forms.TextInput(attrs={'class': 'form-control'}),
            'precio': forms.NumberInput(attrs={'class': 'form-control'}),
            'precio_compra': forms.NumberInput(attrs={'class': 'form-control'}),
            'stock': forms.NumberInput(attrs={'class': 'form-control'}),
        }


class RegistroUsuarioForm(UserCreationForm):
    email = forms.EmailField(required=True, label="Correo electrónico")

    local_fk = forms.ModelChoiceField(
        queryset=Local.objects.all().order_by('numero'),
        label="Selecciona un local",
        required=True,
        widget=forms.Select(attrs={'id': 'local-select', 'class': 'select-local'})
    )

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2', 'local_fk']

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.set_password(self.cleaned_data['password1'])

        if commit:
            user.save()
            local_obj = self.cleaned_data['local_fk']
            Perfil.objects.create(
                user=user,
                local=local_obj.numero,
                nombre_local=local_obj.nombre,
                local_fk=local_obj
            )

        return user






class RegistroUsuarioEncargadoForm(UserCreationForm):
    email = forms.EmailField(required=True, label="Correo electrónico")

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

    def save(self, commit=True, local_id=None, nombre_local=None):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.set_password(self.cleaned_data['password1'])

        if commit:
            user.save()
            
            from .models import Perfil
            Perfil.objects.create(user=user, local=local_id, nombre_local=nombre_local)

        return user





class RegistrarLocalForm(forms.ModelForm):
    class Meta:
        model = Local
        fields = ['numero', 'nombre']
        labels = {
            'numero': 'Número de local',
            'nombre': 'Nombre del local',
        }
        widgets = {
            'numero': forms.TextInput(attrs={'class': 'form-control'}),
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
        }